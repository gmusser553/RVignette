## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup---------------------------------------------------------------
library(AncBAMM)

## ------------------------------------------------------------------------
posteriors <- AncBAMM::curl("https://raw.githubusercontent.com/gmusser553/ADA_Final_Project/master/posterior_tree_set.nex")

## ------------------------------------------------------------------------
f <- AncBAMM::curl("https://raw.githubusercontent.com/gmusser553/ADA_Final_Project/master/mcmc_out.txt")
mcmcout <- read.csv(f, header = TRUE, sep = ",", stringsAsFactors = TRUE)
head(mcmcout)

## ------------------------------------------------------------------------
my_Newick_tree<-AncBAMM::curl("https://raw.githubusercontent.com/gmusser553/ADA_Final_Project/master/MyNewickTreefile.tre")

## ------------------------------------------------------------------------
f<-AncBAMM::curl("https://raw.githubusercontent.com/gmusser553/ADA_Final_Project/master/sevent_data.txt")
sevent <- read.csv(f, header = TRUE, sep = ",", stringsAsFactors = TRUE)
head(sevent)

## ------------------------------------------------------------------------
grui.tree<-AncBAMM::read.nexus(file=posteriors) 

subsettree<-grui.tree[[42]]


## ------------------------------------------------------------------------
AncBAMM::plotTree(subsettree,type="fan",ftype="i", color=gameofthrones::got(150, option = "Targaryen2"), fsize=0.3)

## ------------------------------------------------------------------------
f <- AncBAMM::curl("https://raw.githubusercontent.com/gmusser553/ADA_Final_Project/master/ONLYGruiBodyMassData.csv")
GRUIMassData <- read.csv(f, header = TRUE, sep = ",", stringsAsFactors = TRUE)
head(GRUIMassData)

## ------------------------------------------------------------------------
#data("GRUIMassData")

## ------------------------------------------------------------------------
load(file = "/Users/gracemusser/Desktop/R\ Development/Depos/Spring2019/AncBAMM/data/GRUIMassData.rda")

## ------------------------------------------------------------------------
meanmass<-GRUIMassData$LogMean

names(meanmass)<-GRUIMassData$`Species Name`
xxx <- na.omit(meanmass)

v <- subsettree$tip.label %in% names(xxx)
drop <- subsettree$tip.label[v==FALSE]
d2<-ape::drop.tip(subsettree, drop)

## ------------------------------------------------------------------------
fit<-phytools::fastAnc(tree=d2, xxx, vars=TRUE, CI=TRUE)
fit

## ------------------------------------------------------------------------
obj<-phytools::contMap(d2,xxx,plot=FALSE, res=1000, lwd=.5)

## ------------------------------------------------------------------------
obj<-phytools::setMap(obj, colors=gameofthrones::got(128, option = "Daenerys"))

## ------------------------------------------------------------------------
plot(obj, fsize=.2)

## ------------------------------------------------------------------------
obj<-phytools::setMap(obj, colors=gameofthrones::got(256, option = "Targaryen2"))

plot(obj,type="fan",legend=0.7*max(phytools::nodeHeights(d2)),
     fsize=.2)

## ------------------------------------------------------------------------
phytools::phenogram(d2,xxx,fsize=0.2,spread.costs=c(1,0))

## ------------------------------------------------------------------------
#first use BAMM in terminal-must be Newick notation
#check that tree is ultrametric and all tree lengths are greater than 0:
ape::is.ultrametric(d2) #check if ultrametric
min(d2$edge.length) #check minimum branch length

#After running BAMM, load mcmc_out.txt or equivalent file into R to test convergence using 'coda' package:
#mcmcout <- read.csv("mcmc_out.txt", header=T)
plot(mcmcout$logLik ~ mcmcout$generation)

#next: discard burnin
burnstart <- floor(0.1 * nrow(mcmcout))
postburn <- mcmcout[burnstart:nrow(mcmcout), ]

#check the effective sample sizes of the log-likelihood and the number of shift events present in each 
#you want this to be at least 200
#effectiveSize(postburn$N_shifts)
#effectiveSize(postburn$logLik)

#tree <- read.tree("MyNewickTreefile.tre")
tree<-ape::read.tree(my_Newick_tree)
edata <- BAMMtools::getEventData(tree, eventdata = sevent, burnin=0.1)

shift_probs <- summary(edata) #create dataframe of posterior probabilities
#visualizing mean, model-averaged diversification rates at any point along every branch of a phylogenetic tree:
BAMMtools::plot.bammdata(edata, lwd=2, legend=T)

index <- 25
e2 <- BAMMtools::subsetEventData(edata, index = index)
BAMMtools::plot.bammdata(e2, lwd=2, legend=TRUE)
BAMMtools::addBAMMshifts(e2, cex=2)

## ------------------------------------------------------------------------
BAMMtools::plotRateThroughTime(edata)

## ------------------------------------------------------------------------
D.scores <- GRUIMassData$LogMean
names(D.scores) <- GRUIMassData$`Species Name`

is.D.scores.in.edata <- names(D.scores) %in% edata$tip.label
  
D.scores.trim <- D.scores[is.D.scores.in.edata==TRUE]

  is.edata.in.D.scores <- edata$tip.label %in% names(D.scores.trim)

  keep <- edata$tip.label[is.edata.in.D.scores == TRUE]
  
  edata.subset <- BAMMtools::subtreeBAMM(edata, tips=keep)
  
 cor.result <- BAMMtools::traitDependentBAMM(edata.subset, traits=D.scores.trim,
                                     reps=1000, return.full = TRUE,
                                    method="s",logrates = TRUE,
                                    two.tailed = TRUE)
 
 #correlation
hist(cor.result$estimate, xlim=c(-1,1))
hist(cor.result$obs.corr, xlim=c(-1,1))
cor.result$estimate
cor.result$p.value

